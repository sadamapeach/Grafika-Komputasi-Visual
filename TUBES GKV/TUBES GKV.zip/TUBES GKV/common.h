#ifndef COMMON_H_INCLUDED
#define COMMON_H_INCLUDED

#include <windows.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#endif // COMMON_H_INCLUDED
