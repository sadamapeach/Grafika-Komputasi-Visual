#ifndef TRUK_H_INCLUDED
#define TRUK_H_INCLUDED

void collisionBox(float putaran, float tx, float ty, float tz);
void TrukGandeng(float putaran, float x, float y, float z);

#endif // TRUK_H_INCLUDED
