#ifndef LANTAI_H_INCLUDED
#define LANTAI_H_INCLUDED

void Jalan();
void lantai();
void trotoar(float x);
void roadsideRight(float x);
void roadsideLeft(float x);
#endif // LANTAI_H_INCLUDED

